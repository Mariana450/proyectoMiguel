<?php
session_start();

include_once("cabecera.html"); // Incluye el HTML de la cabecera
include_once("menu.php");     // Incluye el menú de navegación

$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "tsito";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $identificador = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"];

    $user_found = false;

    // --- INTENTAR LOGUEAR COMO VOLUNTARIO ---
    $stmt_voluntario = $conn->prepare("SELECT id, CORREO, CONTRASEÑA, NOMBRE FROM VOLUNTARIOS WHERE CORREO = ?"); // Consulta tabla VOLUNTARIOS
    $stmt_voluntario->bind_param("s", $identificador);
    $stmt_voluntario->execute();
    $result_voluntario = $stmt_voluntario->get_result();

    if ($result_voluntario->num_rows > 0) {
        $row_voluntario = $result_voluntario->fetch_assoc();
        if (password_verify($password, $row_voluntario["CONTRASEÑA"])) { // Verifica CONTRASEÑA
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $row_voluntario["id"]; // Usa 'id'
            $_SESSION["correo"] = $row_voluntario["CORREO"]; // Usa 'CORREO'
            $_SESSION["nombre_usuario"] = $row_voluntario["NOMBRE"]; // Usa 'NOMBRE'
            $_SESSION["rol"] = "voluntario";

            $user_found = true;
            header("Location: eventos.php"); // Redirige a eventos.php
            exit();
        } else {
            $mensaje = "Contraseña incorrecta.";
        }
    }
    $stmt_voluntario->close();

    // --- SI NO SE ENCONTRÓ COMO VOLUNTARIO, INTENTAR COMO ADMINISTRADOR ---
    if (!$user_found) {
        $stmt_admin = $conn->prepare("SELECT NOMBREUSUARIO, CONTRASEÑA, NOMBRECOMPLETO FROM ADMINISTRADOR WHERE NOMBREUSUARIO = ?"); // Consulta tabla ADMINISTRADOR
        $stmt_admin->bind_param("s", $identificador);
        $stmt_admin->execute();
        $result_admin = $stmt_admin->get_result();

        if ($result_admin->num_rows > 0) {
            $row_admin = $result_admin->fetch_assoc();
            if (password_verify($password, $row_admin["CONTRASEÑA"])) { // Verifica CONTRASEÑA
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $row_admin["NOMBREUSUARIO"]; // Usa 'NOMBREUSUARIO'
                $_SESSION["nombre_usuario"] = $row_admin["NOMBRECOMPLETO"]; // Usa 'NOMBRECOMPLETO'
                $_SESSION["rol"] = "admin";

                $user_found = true;
                header("Location: eventos.php"); // Redirige a eventos.php para que también vea la bienvenida y el menú
                exit();
            } else {
                $mensaje = "Contraseña incorrecta.";
            }
        }
        $stmt_admin->close();
    }

    if (!$user_found) {
        $mensaje = "Usuario o correo no registrado. Por favor, <a href='registrar.php'>regístrate aquí</a> si eres voluntario.";
    }
}

$conn->close();
?>

    <div class="contenedor-formulario"><br><br>
        <main class="contenido">
            <h2>Iniciar Sesión</h2>
            <?php if (!empty($mensaje)): ?>
                <p style="color: red; text-align: center;"><?php echo $mensaje; ?></p>
            <?php endif; ?>

            <form action="login.php" method="POST">
                <label for="identificador">Usuario / Correo Electrónico:</label>
                <input type="text" id="identificador" name="email" required>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
                <br>
                <button class="btn-iniciar" type="submit">Iniciar Sesión</button>
            </form>
            <p style="text-align: center;">¿No tienes una cuenta de voluntario?</p>
            <a href="registrar.php" class="btn-registrar" style="display: block; text-align: center;">Regístrate como voluntario aquí</a>
        </main>

    <div class="contenedor-aside">
         <?php include 'aside.html'; ?>
    </div>
    </div>
<br><br>
    <?php include 'pie.html'; ?>

</html>