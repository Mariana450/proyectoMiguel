<!--ContribucionesView-->
<?php 
include_once("cabecera.html");
include_once("menu.php");
?> 

    <div class="contenedor" >
    <main>
      <h2 style="text-align:center;">Registro de contribuciones</h2>
      <form class="formulario" >
        <div class="form-row">
          <label for="nombre">Nombre:</label>
          <input type="text" id="nombre" name="nombre" required />
        </div>

        <div class="form-row">
          <label for="appaterno">Apellido Paterno:</label>
          <input type="text" id="appaterno" name="appaterno" required />
        </div>

        <div class="form-row">
          <label for="apmaterno">Apellido Materno:</label>
          <input type="text" id="apmaterno" name="apmaterno" required />
        </div>

        <div class="form-row">
          <label for="pais">País:</label>
          <input type="text" id="pais" name="pais" required />
        </div>

        <div class="form-row">
          <label for="tipo">Tipo de contribución:</label>
          <select id="tipo" name="tipo" required>
            <option value="">Selecciona una opción</option>
            <option value="material">Mesas</option>
            <option value="material">Sillas</option>
            <option value="voluntariado">Voluntariado</option>
            <option value="servicios">Servicios</option>
          </select>
        </div>

        <button type="submit">Registrar</button>
      </form>
    </main>

    <br /><br />
        <?php include 'aside.html'; ?>

    </div>

    <?php include 'pie.html'; ?>
</body>
</html>
