<?php
session_start();

// Eliminar todas las variables de sesión
$_SESSION = array();

// Destruir la sesión. Esto también destruirá la cookie de sesión.
// Nota: Esto forzará el cierre de sesión en todas las ventanas del navegador.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

// Redirigir al usuario a la página de inicio de sesión o a la principal
header("Location: login.php"); // Redirige a la página de login
exit();
?>