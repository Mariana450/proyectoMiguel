-- 1. Tabla de usuarios
CREATE TABLE usuarios (
    usuario_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL,
    contraseña VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabla de eventos
CREATE TABLE eventos (
    evento_id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE,
    lugar VARCHAR(150),
    cupo INT,
    horas_estimadas INT,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Tabla de inscripciones (relación usuarios , eventos)
CREATE TABLE inscripciones (
    inscripcion_id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    evento_id INT,
    fecha_inscripcion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    horas_participadas INT DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(usuario_id) ON DELETE CASCADE,
    FOREIGN KEY (evento_id) REFERENCES eventos(evento_id) ON DELETE CASCADE
);

-- 4. Tabla de impacto social por evento (opcional para dashboard)
/*CREATE TABLE impacto_social (
    impacto_id INT AUTO_INCREMENT PRIMARY KEY,
    evento_id INT,
    descripcion VARCHAR(200),
    valor INT,
    FOREIGN KEY (evento_id) REFERENCES eventos(evento_id) ON DELETE CASCADE
);*/
