const slides = document.querySelectorAll('.slide');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');
let currentSlide = 0;
let slideInterval;

// Función para mostrar una imagen
function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
  });
}

// Función para ir a la siguiente imagen
function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

// Función para ir a la anterior imagen
function prevSlide() {
  currentSlide = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(currentSlide);
}

// Iniciar el cambio automático
function startSlideShow() {
  slideInterval = setInterval(nextSlide, 5000); // cambia cada 5 segundos
}

// Detener temporalmente el slide automático
function stopSlideShow() {
  clearInterval(slideInterval);
}

// Eventos de los botones
prevBtn.addEventListener('click', () => {
  stopSlideShow();
  prevSlide();
  startSlideShow(); // reinicia el temporizador
});

nextBtn.addEventListener('click', () => {
  stopSlideShow();
  nextSlide();
  startSlideShow(); // reinicia el temporizador
});

// Inicializar slider
showSlide(currentSlide);
startSlideShow();
