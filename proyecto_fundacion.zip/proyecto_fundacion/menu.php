<?php
// NOTA IMPORTANTE:
// session_start() NO debe estar aquí si este archivo se incluye en otros
// que YA tienen session_start() al principio (como index.php, login.php, eventos.php, etc.).
// Para tu configuración actual, si index.php, eventos.php, etc., tienen session_start()
// al inicio, este archivo NO lo necesita.

// Se asume que $_SESSION["rol"] ya fue establecido en el login
?>
<nav>
  <a href="index.php">Inicio</a>
  <a href="index.php#about">Sobre nosotros</a>
  <a href="eventos.php">Eventos</a>
  <a href="contribuciones.php">Contribuciones</a>

  <?php
  // Verifica si el usuario ha iniciado sesión
  if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
      // Si el usuario es un administrador, muestra la opción "Publicar Nuevo Evento"
      if (isset($_SESSION["rol"]) && $_SESSION["rol"] === "admin") {
          echo '<a href="publicar.php">Publicar Nuevo Evento</a>';
      }
      // Siempre muestra la opción de cerrar sesión si está logueado
      echo '<a href="logout.php">Cerrar Sesión</a>';
  } else {
      // Si NO está logueado, muestra el enlace para "Iniciar sesión/ Registrarse"
      echo '<a href="login.php">Iniciar sesión/ Registrarse</a>';
  }
  ?>
</nav>