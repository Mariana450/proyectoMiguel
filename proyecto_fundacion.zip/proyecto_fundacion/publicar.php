<?php
session_start(); // Inicia la sesión al principio del script

// *** Protección de Acceso: Solo administradores pueden acceder a esta página ***
// Si el usuario no está logueado, redirigirlo a la página de login
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: login.php");
    exit();
}

// Si no es un administrador, redirigir a una página de acceso denegado o a la página principal
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] !== "admin") {
    header("Location: index.php"); // Redirige a la página principal si no es admin
    exit();
}

// Incluir la cabecera y el menú
include_once("cabecera.html"); //
include_once("menu.php");     //

// *** CONFIGURACIÓN DE LA BASE DE DATOS ***
$servername = "localhost";
$username_db = "root";   // <-- ¡CAMBIA ESTO! Tu usuario de MySQL en XAMPP
$password_db = "";       // <-- ¡CAMBIA ESTO! Tu contraseña de MySQL en XAMPP
$dbname = "tsito";       // Tu nombre de base de datos

// Crear conexión a la base de datos
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = ""; // Variable para almacenar mensajes de estado

// Procesar el formulario cuando se envíe
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger y limpiar los datos del formulario
    $nombre_evento = $conn->real_escape_string($_POST["evento"]);
    $fecha_evento = $conn->real_escape_string($_POST["fecha"]);
    $hora_evento = $conn->real_escape_string($_POST["hora"]); // Aunque la tabla EVENTOS no tiene 'hora', se puede usar para la descripción o no guardar
    // Asegurarse de que el usuario administrador esté en la sesión
    $admin_usuario = isset($_SESSION["id"]) ? $_SESSION["id"] : null; // Asumiendo que $_SESSION["id"] guarda NOMBREUSUARIO para admins

    // Validar que se haya obtenido el nombre de usuario del administrador
    if ($admin_usuario === null) {
        $mensaje = "<p style='color: red;'>Error: No se pudo identificar al administrador. Por favor, reinicia sesión.</p>";
    } else {
        // Combinar fecha y hora si tuvieras un campo DATETIME.
        // Como tu tabla EVENTOS tiene solo FECHA (DATE), guardaremos solo la fecha.
        // Si quisieras la hora, tendrías que añadir un campo de tipo TIME en tu tabla EVENTOS.
        // O podrías concatenarlo a la descripción si fuera relevante mostrarlo.

        // Preparar la consulta SQL para insertar el nuevo evento
        // La tabla EVENTOS tiene ID, NOMBRE, FECHA, ADMIN_USUARIO
        $stmt = $conn->prepare("INSERT INTO EVENTOS (NOMBRE, FECHA, ADMIN_USUARIO) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nombre_evento, $fecha_evento, $admin_usuario); // 'sss' para tres strings

        // Ejecutar la consulta
        if ($stmt->execute()) {
            $mensaje = "<p style='color: green;'>¡Evento '$nombre_evento' publicado exitosamente!</p>";
            // Opcional: Redirigir después de publicar para evitar reenvío del formulario
            // header("Location: eventos.php");
            // exit();
        } else {
            $mensaje = "<p style='color: red;'>Error al publicar el evento: " . $stmt->error . "</p>";
        }

        $stmt->close(); // Cerrar la sentencia preparada
    }
}

$conn->close(); // Cerrar la conexión a la base de datos
?>

<body>

    <div class="contenedor" style="width: 100%; height: auto;"><br><br>
        <main class="contenido" style="text-align: center;">
            
            <h1>Publicar Nuevo Evento</h1>

            <?php if (!empty($mensaje)): ?>
                <div style="margin-bottom: 20px;">
                    <?php echo $mensaje; ?>
                </div>
            <?php endif; ?>

            <form action="publicar.php" method="POST" enctype="multipart/form-data">
                <label for="evento">Nombre del evento:</label>
                <input type="text" id="evento" name="evento" required><br><br>

                <label for="fecha">Fecha:</label>
                <input type="date" id="fecha" name="fecha" required><br><br>

                <label for="hora">Hora (referencia):</label>
                <input type="time" id="hora" name="hora"><br><br>

                <div class="archivo-container">
                    <label for="archivo">Subir archivo (opcional):</label>
                    <input class="archivo" type="file" id="archivo" name="archivo">
                </div>
                <br>
                
                <div style="text-align: center;">
                    <button type="submit" class="btn-registrar">Publicar Evento</button>
                </div>
            </form>
        
        </main>
        
        <div class="contenedor-aside">
            <?php include 'aside.html'; ?>
        </div>
    </div>
    <br><br>
    <?php include 'pie.html'; ?>
</body>
</html>