<?php
session_start();

// *** Protección de Acceso: Solo administradores pueden acceder ***
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || !isset($_SESSION["rol"]) || $_SESSION["rol"] !== "admin") {
    header("Location: login.php"); // Redirige al login si no es admin o no está logueado
    exit();
}

// Incluir la cabecera y el menú
include_once("cabecera.html"); //
include_once("menu.php");     //

// *** CONFIGURACIÓN DE LA BASE DE DATOS ***
$servername = "localhost";
$username_db = "root";   // <-- ¡VERIFICA TUS CREDENCIALES!
$password_db = "";       // <-- ¡VERIFICA TUS CREDENCIALES!
$dbname = "tsito";       // Tu nombre de base de datos

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = "";
$evento_id = null;
$nombre_evento_a_eliminar = "";
$mostrar_confirmacion = false;

// --- Lógica para Cargar Datos del Evento y Pedir Confirmación (cuando se llega por GET con un ID) ---
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $evento_id = filter_var($_GET["id"], FILTER_SANITIZE_NUMBER_INT); // Sanitizar el ID

    if (!empty($evento_id)) {
        $stmt = $conn->prepare("SELECT ID, NOMBRE FROM EVENTOS WHERE ID = ?");
        $stmt->bind_param("i", $evento_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $nombre_evento_a_eliminar = htmlspecialchars($row["NOMBRE"]);
            $mostrar_confirmacion = true; // Mostrar la sección de confirmación
        } else {
            $mensaje = "<p style='color: red;'>Evento no encontrado.</p>";
        }
        $stmt->close();
    } else {
        $mensaje = "<p style='color: red;'>ID de evento inválido.</p>";
    }
}

// --- Lógica para Procesar la Eliminación (cuando se envía el formulario de confirmación por POST) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["confirmar_eliminar"]) && isset($_POST["evento_id"])) {
    $evento_id_a_eliminar = filter_var($_POST["evento_id"], FILTER_SANITIZE_NUMBER_INT);

    if (!empty($evento_id_a_eliminar)) {
        // Preparar la consulta SQL para eliminar el evento
        $stmt = $conn->prepare("DELETE FROM EVENTOS WHERE ID = ?");
        $stmt->bind_param("i", $evento_id_a_eliminar); // 'i' para entero

        if ($stmt->execute()) {
            $mensaje = "<p style='color: green;'>Evento eliminado exitosamente.</p>";
            // Opcional: Redirigir a la lista de eventos después de eliminar
            header("Location: eventos.php?eliminado=true");
            exit();
        } else {
            $mensaje = "<p style='color: red;'>Error al eliminar el evento: " . $stmt->error . "</p>";
        }
        $stmt->close();
    } else {
        $mensaje = "<p style='color: red;'>ID de evento no especificado para eliminar.</p>";
    }
}

$conn->close();
?>

<body>

    <div class="contenedor" style="width: 100%; height: auto;"><br><br>
        <main class="contenido" style="text-align: center;">
            
            <h1>Eliminar Evento</h1>

            <?php if (!empty($mensaje)): ?>
                <div style="margin-bottom: 20px;">
                    <?php echo $mensaje; ?>
                </div>
            <?php endif; ?>

            <?php if ($mostrar_confirmacion): ?>
                <p>¿Estás seguro de que quieres eliminar el evento:</p>
                <p style="font-weight: bold; font-size: 1.2em;"><?php echo $nombre_evento_a_eliminar; ?>?</p>
                
                <form action="eliminarEven.php" method="POST">
                    <input type="hidden" name="evento_id" value="<?php echo $evento_id; ?>">
                    <button type="submit" name="confirmar_eliminar" class="btn-eliminar" style="background-color: #dc3545;">Sí, Eliminar</button>
                    <a href="eventos.php" class="btn" style="text-decoration: none; padding: 10px 20px; background-color: #6c757d; color: white; border-radius: 5px; margin-left: 10px;">Cancelar</a>
                </form>
            <?php elseif (empty($mensaje)): // Si no hay ID válido para confirmar y no hay mensaje, mostrar instrucción ?>
                <p>Por favor, selecciona un evento para eliminar desde la lista de eventos.</p>
                <a href="eventos.php" class="btn" style="text-decoration: none; padding: 10px 20px; background-color: #007bff; color: white; border-radius: 5px;">Ir a Eventos</a>
            <?php endif; ?>
        
        </main>
        
        <div class="contenedor-aside">
            <?php include 'aside.html'; ?>
        </div>
    </div>
    <br><br>
    <?php include 'pie.html'; ?>
</body>
</html>