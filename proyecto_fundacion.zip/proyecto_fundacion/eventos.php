<?php
session_start(); // Inicia la sesión al principio de la página

// *** Protección de Acceso: Redirigir si no está logueado ***
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("Location: login.php");
    exit();
}

// Recuperar el nombre del usuario de la sesión para el mensaje de bienvenida
// Se asume que $_SESSION["nombre_usuario"] contiene el nombre del voluntario o el nombre completo del administrador
$nombre_usuario_logueado = isset($_SESSION["nombre_usuario"]) ? htmlspecialchars($_SESSION["nombre_usuario"]) : "Usuario";

// Define si es administrador basándose en el rol almacenado en la sesión
$esAdmin = (isset($_SESSION["rol"]) && $_SESSION["rol"] === "admin");

// Incluir la cabecera y el menú
include_once("cabecera.html"); //
include_once("menu.php");     //

// *** CONFIGURACIÓN Y CONEXIÓN A LA BASE DE DATOS ***
$servername = "localhost";
$username_db = "root";   // <-- ¡VERIFICA TUS CREDENCIALES DE MySQL!
$password_db = "";       // <-- ¡VERIFICA TUS CREDENCIALES DE MySQL! (vacío por defecto en XAMPP)
$dbname = "tsito";       // Tu nombre de base de datos, según tsito_database_con_relaciones.sql

// Crear conexión
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// *** LÓGICA PARA RECUPERAR EVENTOS DE LA BASE DE DATOS ***
// Selecciona ID, NOMBRE, FECHA y el usuario administrador que creó el evento
// Ordena por fecha de forma descendente (los más recientes primero)
$sql_eventos = "SELECT ID, NOMBRE, FECHA, ADMIN_USUARIO FROM EVENTOS ORDER BY FECHA DESC";
$result_eventos = $conn->query($sql_eventos);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos - Fundación Tsito</title>
    <link rel="stylesheet" href="CSS/style.css"> </head>
<body>

    <div class="contenedor" style="width: 100%; height: auto;"><br><br>
        <main class="contenido">
            <h2 style="text-align:center;">¡Bienvenido, <?php echo $nombre_usuario_logueado; ?>!</h2>
            <p style="text-align:center;">Estos son los eventos disponibles para ti.</p>

            <h2 style="text-align:center;">Eventos Registrados</h2>

            <div class="eventos-container" id="eventosContainer">
                <?php
                // Verificar si hay eventos en la base de datos
                if ($result_eventos->num_rows > 0) {
                    // Iterar sobre cada fila de resultados y mostrar el evento
                    while ($row_evento = $result_eventos->fetch_assoc()) {
                        $id_evento = htmlspecialchars($row_evento["ID"]);
                        $nombre_evento = htmlspecialchars($row_evento["NOMBRE"]);
                        $fecha_evento = htmlspecialchars($row_evento["FECHA"]);
                        $admin_creador = htmlspecialchars($row_evento["ADMIN_USUARIO"]);

                        echo '<div class="publicacion">';
                        echo '<h3>' . $nombre_evento . '</h3>';
                        echo '<p><strong>Fecha:</strong> ' . $fecha_evento . '</p>';
                        echo '<p>Publicado por: ' . $admin_creador . '</p>'; // Muestra quién lo publicó
                        echo '<div class="botones">';

                        if ($esAdmin) {
                            // Botones para modificar y eliminar solo si es administrador
                            // Estos enlaces ahora apuntan a los archivos renombrados
                            echo '<a href="modificarEven.php?id=' . $id_evento . '" class="modificar-btn" style="text-decoration: none; display: inline-block; padding: 8px 15px; background-color: #007bff; color: white; border-radius: 5px; margin-right: 10px;">Modificar publicación</a>';
                            echo '<a href="eliminarEven.php?id=' . $id_evento . '" class="eliminar-btn" style="text-decoration: none; display: inline-block; padding: 8px 15px; background-color: #dc3545; color: white; border-radius: 5px;">Eliminar publicación</a>';
                        } else {
                            // Botón de inscribirse para voluntarios (o usuarios normales)
                            echo '<button class="inscribirse-btn" data-id="' . $id_evento . '" style="padding: 8px 15px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer;">Inscribirse</button>';
                        }
                        echo '</div>'; // Cierre de div botones
                        echo '</div>'; // Cierre de div publicacion
                    }
                } else {
                    // Mensaje si no hay eventos registrados en la base de datos
                    echo '<p style="text-align: center;">No hay eventos registrados aún. ¡Pronto tendremos más!</p>';
                }
                ?>
            </div>
        </main>

        <div class="contenedor-aside">
            <?php include 'aside.html'; ?>
        </div>
    </div>

    <br><br>
    <?php include 'pie.html'; ?>
</body>
</html>

<?php
// Cerrar la conexión a la base de datos al final del script
$conn->close();
?>