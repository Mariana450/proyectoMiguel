<?php
session_start();

include_once("cabecera.html");
include_once("menu.php");

// *** CONEXIÓN A LA BASE DE DATOS ***
$servername = "localhost";
$username_db = "root"; // CAMBIA ESTO por tu usuario de MySQL
$password_db = "";     // CAMBIA ESTO por tu contraseña de MySQL
$dbname = "tsito";     // Tu nombre de base de datos

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $apellidoPaterno = $_POST["apellidoPaterno"];
    $apellidoMaterno = $_POST["apellidoMaterno"];
    $correo = $_POST["correo"];
    $sexo = $_POST["sexo"];
    $telefono = $_POST["telefono"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Validaciones básicas
    if (empty($nombre) || empty($apellidoPaterno) || empty($apellidoMaterno) || empty($correo) || empty($sexo) || empty($password) || empty($confirm_password)) {
        $mensaje = "Por favor, completa todos los campos requeridos.";
    } elseif ($password !== $confirm_password) {
        $mensaje = "Las contraseñas no coinciden.";
    } elseif (strlen($password) < 6) { // Ejemplo: mínimo 6 caracteres
        $mensaje = "La contraseña debe tener al menos 6 caracteres.";
    } else {
        // Verificar si el correo ya está registrado
        $stmt_check = $conn->prepare("SELECT id FROM VOLUNTARIOS WHERE CORREO = ?");
        $stmt_check->bind_param("s", $correo);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $mensaje = "Este correo ya está registrado. Por favor, <a href='login.php'>inicia sesión</a>.";
        } else {
            // Hash de la contraseña
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insertar nuevo voluntario
            $stmt_insert = $conn->prepare("INSERT INTO VOLUNTARIOS (NOMBRE, APELLIDOPATERNO, APELLIDOMATERNO, CORREO, SEXO, TELEFONO, CONTRASEÑA) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt_insert->bind_param("sssssss", $nombre, $apellidoPaterno, $apellidoMaterno, $correo, $sexo, $telefono, $hashed_password);

            if ($stmt_insert->execute()) {
                $mensaje = "¡Registro exitoso! Ahora puedes iniciar sesión.";
                // Opcional: Iniciar sesión automáticamente después del registro
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $conn->insert_id;
                $_SESSION["correo"] = $correo;
                $_SESSION["nombre_voluntario"] = $nombre;
                header("Location: eventos.php"); // Redirige a una página de bienvenida
                exit();
            } else {
                $mensaje = "Error al registrar: " . $stmt_insert->error;
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
    }
}

$conn->close();
?>

    <div class="contenedor-formulario"><br><br>
        <main class="contenido">
            <h2>Registrarse como Voluntario</h2>
            <p style="color: red;"><?php echo $mensaje; ?></p> <form action="registrar.php" method="POST">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required><br>

                <label for="apellidoPaterno">Apellido Paterno:</label>
                <input type="text" id="apellidoPaterno" name="apellidoPaterno" required><br>

                <label for="apellidoMaterno">Apellido Materno:</label>
                <input type="text" id="apellidoMaterno" name="apellidoMaterno" required><br>

                <label for="correo">Correo Electrónico:</label>
                <input type="email" id="correo" name="correo" required><br>

                <label for="sexo">Sexo:</label>
                <select id="sexo" name="sexo" required>
                    <option value="">Selecciona</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                    <option value="Otro">Otro</option>
                </select><br>

                <label for="telefono">Teléfono (opcional):</label>
                <input type="text" id="telefono" name="telefono"><br>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required><br>

                <label for="confirm_password">Confirmar Contraseña:</label>
                <input type="password" id="confirm_password" name="confirm_password" required><br>

                <br>
                <button class="btn-registrar" type="submit">Registrarme</button>
            </form>
            <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión aquí</a></p>
        </main>

    <div class="contenedor-aside">
         <?php include 'aside.html'; ?>
    </div>
    </div>
<br><br>
    <?php include 'pie.html'; ?>

</html>