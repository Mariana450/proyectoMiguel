INSERT INTO usuarios (nombre, correo, contraseña) VALUES
('María González', 'maria@gmail.com', '12345'),
('Carlos Pérez', 'carlos@gmail.com', 'abcde'),
('Ana Martínez', 'ana@gmail.com', 'clave123'),
('Luis Rodríguez', 'luis@gmail.com', 'seguro456');

INSERT INTO eventos (nombre, descripcion, fecha_inicio, fecha_fin, lugar, cupo, horas_estimadas) VALUES
('Campaña de Vacunación', 'Vacunación gratuita para la comunidad', '2025-06-01', '2025-06-02', 'Centro de Salud', 100, 5),
('Limpieza de Playa', 'Jornada de limpieza en la playa principal', '2025-06-10', '2025-06-10', 'Playa del Sol', 50, 3),
('Taller de Alfabetización', 'Clases básicas de lectura y escritura', '2025-06-15', '2025-07-15', 'Escuela Primaria 21', 30, 20);


-- Suponiendo que los usuarios y eventos ya tienen IDs del 1 al 3
INSERT INTO inscripciones (usuario_id, evento_id, horas_participadas) VALUES
(1, 1, 5),  -- María en Campaña de Vacunación
(2, 1, 4),  -- Carlos en Campaña de Vacunación
(3, 2, 3),  -- Ana en Limpieza de Playa
(4, 3, 18), -- Luis en Taller de Alfabetización
(1, 3, 20); -- María también en el Taller



INSERT INTO impacto_social (evento_id, descripcion, valor) VALUES
(1, 'Número de personas vacunadas', 100),
(2, 'Cantidad de basura recogida (kg)', 200),
(3, 'Número de personas alfabetizadas', 25);