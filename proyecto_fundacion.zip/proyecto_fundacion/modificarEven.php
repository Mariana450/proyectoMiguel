<?php
session_start();

// *** Protección de Acceso: Solo administradores pueden acceder ***
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || !isset($_SESSION["rol"]) || $_SESSION["rol"] !== "admin") {
    header("Location: login.php"); // Redirige al login si no es admin o no está logueado
    exit();
}

// Incluir la cabecera y el menú
include_once("cabecera.html"); //
include_once("menu.php");     //

// *** CONFIGURACIÓN DE LA BASE DE DATOS ***
$servername = "localhost";
$username_db = "root";   // <-- ¡VERIFICA TUS CREDENCIALES!
$password_db = "";       // <-- ¡VERIFICA TUS CREDENCIALES!
$dbname = "tsito";       // Tu nombre de base de datos

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = "";
$evento_id = null;
$nombre_evento = "";
$fecha_evento = "";
// $hora_evento = ""; // Campo para hora (si existiera en la DB o se manejara en descripción)

// --- Lógica para Cargar Datos del Evento (cuando se llega por GET con un ID) ---
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $evento_id = filter_var($_GET["id"], FILTER_SANITIZE_NUMBER_INT); // Sanitizar el ID

    if (!empty($evento_id)) {
        $stmt = $conn->prepare("SELECT ID, NOMBRE, FECHA FROM EVENTOS WHERE ID = ?");
        $stmt->bind_param("i", $evento_id); // 'i' para entero
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $nombre_evento = htmlspecialchars($row["NOMBRE"]);
            $fecha_evento = htmlspecialchars($row["FECHA"]);
            // Si tuvieras un campo de hora, lo cargarías aquí también
            // $hora_evento = htmlspecialchars($row["HORA"]);
        } else {
            $mensaje = "<p style='color: red;'>Evento no encontrado.</p>";
            $evento_id = null; // Reiniciar ID para no mostrar el formulario de modificación vacío
        }
        $stmt->close();
    } else {
        $mensaje = "<p style='color: red;'>ID de evento inválido.</p>";
    }
}

// --- Lógica para Procesar la Actualización (cuando se envía el formulario por POST) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["evento_id"])) {
    $evento_id = filter_var($_POST["evento_id"], FILTER_SANITIZE_NUMBER_INT);
    $nuevo_nombre = $conn->real_escape_string($_POST["evento"]);
    $nueva_fecha = $conn->real_escape_string($_POST["fecha"]);
    // Si tuvieras hora, la recogerías aquí:
    // $nueva_hora = $conn->real_escape_string($_POST["hora"]);

    if (!empty($evento_id) && !empty($nuevo_nombre) && !empty($nueva_fecha)) {
        $stmt = $conn->prepare("UPDATE EVENTOS SET NOMBRE = ?, FECHA = ? WHERE ID = ?"); // Asumiendo solo nombre y fecha en tu tabla EVENTOS
        $stmt->bind_param("ssi", $nuevo_nombre, $nueva_fecha, $evento_id); // 'ssi' para 2 strings y 1 entero

        if ($stmt->execute()) {
            $mensaje = "<p style='color: green;'>Evento actualizado exitosamente.</p>";
            // Actualizar las variables para que el formulario muestre los nuevos datos
            $nombre_evento = $nuevo_nombre;
            $fecha_evento = $nueva_fecha;
            // $hora_evento = $nueva_hora;
        } else {
            $mensaje = "<p style='color: red;'>Error al actualizar el evento: " . $stmt->error . "</p>";
        }
        $stmt->close();
    } else {
        $mensaje = "<p style='color: red;'>Por favor, completa todos los campos requeridos para la actualización.</p>";
    }
}

$conn->close();
?>

<body>

    <div class="contenedor" style="width: 100%; height: auto;"><br><br>
        <main class="contenido" style="text-align: center;">
            
            <h1>Modificar Evento</h1>

            <?php if (!empty($mensaje)): ?>
                <div style="margin-bottom: 20px;">
                    <?php echo $mensaje; ?>
                </div>
            <?php endif; ?>

            <?php if ($evento_id !== null): // Mostrar formulario solo si hay un evento válido para modificar ?>
                <form action="modificarEven.php" method="POST">
                    <input type="hidden" name="evento_id" value="<?php echo $evento_id; ?>">

                    <label for="evento">Nombre del evento:</label>
                    <input type="text" id="evento" name="evento" value="<?php echo $nombre_evento; ?>" required><br><br>

                    <label for="fecha">Fecha:</label>
                    <input type="date" id="fecha" name="fecha" value="<?php echo $fecha_evento; ?>" required><br><br>

                    <div style="text-align: center;">
                        <button type="submit" class="btn-registrar">Actualizar Evento</button>
                    </div>
                </form>
                <br>
                <a href="eventos.php" class="btn" style="text-decoration: none; padding: 10px 20px; background-color: #007bff; color: white; border-radius: 5px;">Volver a Eventos</a>
            <?php elseif (empty($mensaje)): // Si no hay ID válido y no hay mensaje, mostrar instrucción ?>
                <p>Por favor, selecciona un evento para modificar desde la lista de eventos.</p>
                <a href="eventos.php" class="btn" style="text-decoration: none; padding: 10px 20px; background-color: #007bff; color: white; border-radius: 5px;">Ir a Eventos</a>
            <?php endif; ?>
        
        </main>
        
        <div class="contenedor-aside">
            <?php include 'aside.html'; ?>
        </div>
    </div>
    <br><br>
    <?php include 'pie.html'; ?>
</body>
</html>